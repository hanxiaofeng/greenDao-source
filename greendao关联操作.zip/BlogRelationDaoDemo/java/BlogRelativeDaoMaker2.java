package com.xwtec.sqllite;

import java.io.IOException;

import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Property;
import de.greenrobot.daogenerator.Property.PropertyBuilder;
import de.greenrobot.daogenerator.Schema;

/**
 * 
 * 测试关联关系的使用
 * 1.我们知道，一个人有一张身份证，一张身份证对应一个人，这两者的关系是一对一。
 * 下面我们生成这两个实体类，并进行一对一映射。
 * 
 * 注意：如果指定的实体类名为首字母大写,那么如果在不指定表名的情况下，表名默认为大写，否则按照指定的来
 * 
 * @author wangkeke
 * @version [V1.00, 2016年7月4日]
 * @see [相关类/方法]
 * @since V1.00
 */
public class BlogRelativeDaoMaker2
{
    public static void main(String[] args)
        throws IOException, Exception
    {
        Schema schema = new Schema(1, "com.relation.dao.db.localdb");
        // addHistory(schema);
        addOneToOne(schema);
        addOneToMany(schema);
        addManyToMany(schema);
        addPropertyConverter(schema);
        new DaoGenerator().generateAll(schema, "./blog");
    }
    
    /**
     * 
     * 场景：一个男人只有一个老婆，一个老婆只能嫁一个男人
     * 
     * 【一对一】的关系
     * 
     * @param schema
     * @see [类、类#方法、类#成员]
     */
    private static void addOneToOne(Schema schema)
    {
        /**
         * <男人表>
         */
        Entity man = schema.addEntity("Man");
        // 设置表名
        man.setTableName("man");
        // 身份证号
        man.addStringProperty("cardManNum").columnName("cardmannum").primaryKey();
        // 姓名
        man.addStringProperty("name").columnName("name");
        // 年龄
        man.addIntProperty("age").columnName("age");
        // 家庭住址
        man.addStringProperty("address").columnName("address");
        
        /**
         * <女人表>
         */
        Entity woman = schema.addEntity("Woman");
        // 设置表名
        woman.setTableName("woman");
        // 身份证号
        woman.addStringProperty("cardWomanNum").columnName("cardwomannum").primaryKey();
        // 姓名
        woman.addStringProperty("name").columnName("name");
        // 性别
        woman.addStringProperty("sex").columnName("sex");
        // 年龄
        woman.addIntProperty("age").columnName("age");
        // 家庭住址
        woman.addStringProperty("address").columnName("address");
        
        /**
         * <一对一映射>
         */
        // 在woman表中插入外键(man表的主键)进行关联
        Property cardnum = man.addStringProperty("fkmannum").getProperty();
        man.addToOne(woman, cardnum);
        // 在man表中插入外键(woman表的主键)进行关联
        Property womanCardNum = woman.addStringProperty("fkwomannum").getProperty();
        woman.addToOne(man, womanCardNum);
    }
    
    /**
     * 
     * 【一对多】的关系
     * 
     * 淘宝为例，一位顾客可以有很多订单，
     * 而一个订单只能属于一位顾客，所以这就成了一对多的关系，
     * 假设顾客Customer表有customerId（primaryKey）、name两个属性，
     * 订单Order表有orderId（primaryKey）、money两个属性。
     * 
     * @param schema
     * @see [类、类#方法、类#成员]
     */
    private static void addOneToMany(Schema schema)
    {
        /**
         * 顾客
         */
        Entity customer = schema.addEntity("Customer");
        // 设置表名
        customer.setTableName("customer");
        
        // customerId设置为主键
        customer.addLongProperty("customerId").primaryKey();
        
        customer.addStringProperty("name").columnName("name").notNull();
        
        /**
         * 订单
         */
        Entity orderinfo = schema.addEntity("OrderInfo");
        // 设置表名
        orderinfo.setTableName("orderinfo");
        // 身份证号码设置为主键
        orderinfo.addLongProperty("orderId").primaryKey();
        orderinfo.addDoubleProperty("money").notNull();
        
        /**
         * 一对多关联
         * 
         * 当设置了顾客对订单一对多关联后，Order实体（和表）中会多一个属性为customerId，
         * 所以通过订单我们可以得到该顾客信息，而Customer实体（和表）中会多一个List集合变量：
         * List<Order> orders，表示该顾客的所有订单，其中orders其实是我们自定义的名字，
         * 在刚刚setName("orders")就是给这个变量设置了“orders“名称，
         * 而Customer实体中还提供了一个方法getOrders()表示得到该顾客所有订单
         * 
         */
        Property property = orderinfo.addLongProperty("customerId").getProperty();
        // 一个订单对应一个顾客
        orderinfo.addToOne(customer, property, "customerfk");
        customer.addToMany(orderinfo, property).setName("orders");
        
    }
    
    /**
     * <多对多>
     * 
     * 通常来说，在建立多对多关联上，我们都会采用新建一张中间表，
     * 利用中间表把多对多这种复杂关系简单化，在通常的选课系统上，
     * 一个学生可以选择多门课，一门课可以被多个学生选，这就是多对多关系了，
     * 假设Student有studentId、name两个属性，
     * Course有courseId、courseName两个属性
     * 
     * 
     * @param schema
     * @see [类、类#方法、类#成员]
     */
    private static void addManyToMany(Schema schema)
    {
        // 学生
        Entity student = schema.addEntity("Student");
        student.addLongProperty("studentId").primaryKey();
        student.addStringProperty("name").notNull();
        
        // 课程
        Entity course = schema.addEntity("Course");
        course.addLongProperty("courseId").primaryKey();
        course.addStringProperty("courseName").notNull();
        
        // 建立多对多关系,StudentCourse中间表,简化多对多的关系
        Entity studentCourse = schema.addEntity("StudentCourse");
        studentCourse.addIdProperty().primaryKey();
        
        Property studentId = studentCourse.addLongProperty("studentId").getProperty();
        Property courseId = studentCourse.addLongProperty("courseId").getProperty();
        
        // StudentCourse表分别与student和course表建立一对多关系，实现student和course的多对多
        studentCourse.addToOne(student, studentId);
        studentCourse.addToOne(course, courseId);
        
        student.addToMany(studentCourse, studentId);
        course.addToMany(studentCourse, courseId);
        
    }
    
    /**
     * 添加自定义属性
     * 
     * @param schema
     * @see [类、类#方法、类#成员]
     */
    private static void addPropertyConverter(Schema schema)
    {
        Entity item = schema.addEntity("JsonTable");
        item.addIdProperty().primaryKey();
        //第一个参数是我们转换后的类型的全路径，第二个是转化器类的路径
        item.addStringProperty("model").customType("com.relation.dao.PersonModel", "com.relation.dao.JsonPropertyConverter");
    }
    
}

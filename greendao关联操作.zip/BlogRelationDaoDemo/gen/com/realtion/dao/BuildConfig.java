/** Automatically generated file. DO NOT MODIFY */
package com.realtion.dao;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
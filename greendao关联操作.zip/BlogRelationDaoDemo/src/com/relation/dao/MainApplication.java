package com.relation.dao;

import android.app.Application;

import com.relation.dao.db.DBController;
import com.relation.dao.db.localdb.DaoMaster;

/**
 * 
 * <application类>
 * 
 * @author 王可可
 * @version [V1.00, 2016年6月30日]
 * @see [相关类/方法]
 * @since V1.00
 */
public class MainApplication extends Application
{
    /**
     * 单例对象
     */
    private static MainApplication instance;
    private DaoMaster daoMaster;
    
    @Override
    public void onCreate()
    {
        super.onCreate();
        instance = this;
        //测试用
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, DBController.DATABASE_ECMC_NAME, null);
        daoMaster = new DaoMaster(helper.getWritableDatabase());
    }
    
    public static MainApplication getIns()
    {
        return instance;
    }
}

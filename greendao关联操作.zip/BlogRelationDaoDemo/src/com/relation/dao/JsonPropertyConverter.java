package com.relation.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;

import de.greenrobot.dao.converter.PropertyConverter;

/**
 * 
 * 自定义数据库类型
 * 
 * Json
 */
public class JsonPropertyConverter implements PropertyConverter<PersonModel, String>
{
    // 从数据库取出值后转为实体类里的类型
    @Override
    public PersonModel convertToEntityProperty(String databaseValue)
    {
        Gson gson = new Gson();
        PersonModel model = gson.fromJson(databaseValue, PersonModel.class);
        return model;
    }
    
    // 转换实体类该字段对应的数据库所存放的值
    @Override
    public String convertToDatabaseValue(PersonModel entityProperty)
    {
        Gson gson = new Gson();
        return gson.toJson(entityProperty);
    }
    
}

package com.relation.dao.db;

import android.content.Context;

import com.relation.dao.MainApplication;
import com.relation.dao.db.localdb.DaoMaster;
import com.relation.dao.db.localdb.DaoSession;

/**
 * 数据库控制类
 */
public class DBController
{
    private static DaoMaster daoMasterEcmc;
    
    private static DaoSession daoSessionEcmc;
    
    /**
     * 数据库名称:relative.db
     */
    public static final String DATABASE_ECMC_NAME = "relative.db";
    
    private static DaoMaster obtainMaster(Context context, String dbName)
    {
        return new DaoMaster(new DaoMaster.DevOpenHelper(context, dbName, null).getWritableDatabase());
    }
    
    private static DaoMaster getDaoMaster(Context context, String dbName)
    {
        if (dbName == null)
            return null;
        if (daoMasterEcmc == null)
        {
            daoMasterEcmc = obtainMaster(context, dbName);
        }
        return daoMasterEcmc;
    }
    
    /**
     * 取得DaoSession
     *
     * @return
     */
    public static DaoSession getDaoSession(String dbName)
    {
        
        if (daoSessionEcmc == null)
        {
            daoSessionEcmc = getDaoMaster(MainApplication.getIns(), dbName).newSession();
        }
        return daoSessionEcmc;
    }
    
    /**
     * 默认操作relative数据库
     */
    public static DaoSession getDaoSession()
    {
        
        if (daoSessionEcmc == null)
        {
            daoSessionEcmc = getDaoMaster(MainApplication.getIns(), DATABASE_ECMC_NAME).newSession();
        }
        return daoSessionEcmc;
    }
}

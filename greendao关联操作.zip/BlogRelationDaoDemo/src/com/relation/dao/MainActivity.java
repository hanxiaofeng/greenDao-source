package com.relation.dao;

import java.io.IOException;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.realtion.dao.R;
import com.relation.dao.db.DBController;
import com.relation.dao.db.localdb.Course;
import com.relation.dao.db.localdb.CourseDao;
import com.relation.dao.db.localdb.Customer;
import com.relation.dao.db.localdb.CustomerDao;
import com.relation.dao.db.localdb.JsonTable;
import com.relation.dao.db.localdb.JsonTableDao;
import com.relation.dao.db.localdb.Man;
import com.relation.dao.db.localdb.ManDao;
import com.relation.dao.db.localdb.OrderInfo;
import com.relation.dao.db.localdb.OrderInfoDao;
import com.relation.dao.db.localdb.Student;
import com.relation.dao.db.localdb.StudentCourse;
import com.relation.dao.db.localdb.StudentCourseDao;
import com.relation.dao.db.localdb.StudentDao;
import com.relation.dao.db.localdb.Woman;
import com.relation.dao.db.localdb.WomanDao;

/**
 * 
 * <greenDao关系操作>
 * 
 * @author 王可可
 * @version [V1.00, 2016年7月7日]
 * @see [相关类/方法]
 * @since V1.00
 */
public class MainActivity extends Activity implements OnClickListener
{
    private Button btnInsert, btnSel, btnDel, btnUpdate;
    
    private TextView tvShow;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initView();
    }
    
    private void initView()
    {
        btnInsert = (Button)findViewById(R.id.button_insert);
        btnInsert.setOnClickListener(this);
        btnSel = (Button)findViewById(R.id.button_sel);
        btnSel.setOnClickListener(this);
        tvShow = (TextView)findViewById(R.id.show_tv);
        tvShow.setOnClickListener(this);
        btnDel = (Button)findViewById(R.id.button_del);
        btnDel.setOnClickListener(this);
        btnUpdate = (Button)findViewById(R.id.button_update);
        btnUpdate.setOnClickListener(this);
    }
    
    private MediaPlayer ring(Context context)
        throws Exception, IOException
    {
        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        MediaPlayer player = new MediaPlayer();
        player.setDataSource(context, alert);
        final AudioManager audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager.getStreamVolume(AudioManager.STREAM_NOTIFICATION) != 0)
        {
            player.setAudioStreamType(AudioManager.STREAM_NOTIFICATION);
            player.setLooping(false);
            player.prepare();
            player.start();
        }
        return player;
    }
    
    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.button_insert:
                // 一对一插入
                // insertData();
                // 一对多插入
                // insertOneToManyData();
                // 多对多插入
                insertManyToManyData();
                break;
            case R.id.button_sel:
                // 一对一查询
                // selData();
                // 一对多查询
                // selOneToManyData();
                // 多对多查询
                selManyToManyData();
                break;
            case R.id.button_del:
                // 一对一清空
                // clearData();
                // 一对多清空
                // clearOneToManyData();
                // 多对多清空
                clearManyToManyData();
                break;
            case R.id.button_update:
//                updateData();
                
//                testJsonPropertyConverter();
                
                selJsonProConverter();
                break;
            default:
                break;
        }
    }
    
    private void selJsonProConverter()
    {
        JsonTableDao jsonTableDao = DBController.getDaoSession().getJsonTableDao();
        
        JsonTable jsonTable = jsonTableDao.queryBuilder().where(JsonTableDao.Properties.Id.eq(1)).unique();
        
        PersonModel model = jsonTable.getModel();
        
        showDbData(model.toString());
        
    }

    private void testJsonPropertyConverter()
    {
        JsonTableDao jsonTableDao = DBController.getDaoSession().getJsonTableDao();
        
        JsonTable jsonTable = new JsonTable(); 
        
        PersonModel model = new PersonModel();
        model.setName("周星驰");
        model.setAge("45");
        jsonTable.setModel(model);
        
        jsonTableDao.insertInTx(jsonTable);
    }

    private void updateData()
    {
        /*
         * ManDao manDao = DBController.getDaoSession().getManDao();
         * WomanDao womanDao = DBController.getDaoSession().getWomanDao();
         * 
         * // Woman women = womanDao.queryBuilder().where(WomanDao.Properties.Name.eq("花花")).unique();
         * // women.setName("老花花鱼");
         * Man man = manDao.queryBuilder().where(ManDao.Properties.Name.eq("王坤")).unique();
         * 
         * man.setName("旭开学");
         */
        
        // man.setWoman(women);
        // women.setMan(man);
        
        // manDao.update(man);
        // womanDao.update(women);
        
        /*
         * CustomerDao customerDao = DBController.getDaoSession().getCustomerDao();
         * 
         * Customer customer = customerDao.queryBuilder().where(CustomerDao.Properties.Name.eq("李四")).unique();
         * 
         * customer.setCustomerId((long)30001);
         * 
         * customerDao.updateInTx(customer);
         * 
         * OrderInfoDao orderInfoDao = DBController.getDaoSession().getOrderInfoDao();
         * customer.resetOrders();
         * 
         * List<OrderInfo> orderInfos = customer.getOrders();
         * for (int i = 0; i < orderInfos.size(); i++)
         * {
         * OrderInfo orderInfo = orderInfos.get(i);
         * orderInfo.setCustomerId((long)30001);
         * orderInfoDao.updateInTx(orderInfo);
         * }
         */
        
        // ManDao manDao = DBController.getDaoSession().getManDao();
        // Man man = manDao.queryBuilder().where(ManDao.Properties.Name.eq("王坤")).unique();
        // man.setCardManNum("444455556666");
        // manDao.update(man);
        
        /*
         * CourseDao courseDao = DBController.getDaoSession().getCourseDao();
         * Course courseup = courseDao.queryBuilder().where(CourseDao.Properties.CourseName.eq("数学")).list().get(0);
         * 
         * 
         * if (null != courseup)
         * {
         * // courseDao.refresh(courseup);
         * // courseup.resetStudentCourseList();
         * // courseup.setCourseId((long)50002);
         * // courseDao.updateInTx(courseup);
         * 
         * StudentCourseDao studentCourseDao = DBController.getDaoSession().getStudentCourseDao();
         * courseup.resetStudentCourseList();
         * List<StudentCourse> studentCourses = courseup.getStudentCourseList();
         * for (int i = 0; i < studentCourses.size(); i++)
         * {
         * StudentCourse studentCourse = studentCourses.get(i);
         * studentCourse.setCourseId((long)50002);
         * studentCourseDao.updateInTx(studentCourse);
         * }
         * 
         * courseup.setCourseId((long)50002);
         * courseDao.updateInTx(courseup);
         * }
         */
    }
    
    /**
     * 多对多清空数据
     * 
     * @see [类、类#方法、类#成员]
     */
    private void clearManyToManyData()
    {
        DBController.getDaoSession().getStudentDao().deleteAll();
        DBController.getDaoSession().getStudentCourseDao().deleteAll();
        DBController.getDaoSession().getCourseDao().deleteAll();
    }
    
    /**
     * 查询数据(多对多)
     * 
     * @see [类、类#方法、类#成员]
     */
    private void selManyToManyData()
    {
        // 查询老王选课
        
        StudentDao studentDao = DBController.getDaoSession().getStudentDao();
        
        List<Student> students = studentDao.queryBuilder().where(StudentDao.Properties.Name.eq("老王")).list();
        
        StringBuilder builder = new StringBuilder();
        
        Student student = students.get(0);
        
        List<StudentCourse> studentCourses = student.getStudentCourseList();
        
        for (int i = 0; i < studentCourses.size(); i++)
        {
            StudentCourse studentCourse = studentCourses.get(i);
            Course course = studentCourse.getCourse();
            builder.append("----课程:" + course.getCourseName() + "----课程ID:" + course.getCourseId());
            builder.append("\n");
        }
        showDbData(builder.toString());
        
    }
    
    /**
     * 插入数据(多对多)
     * 
     * @see [类、类#方法、类#成员]
     */
    private void insertManyToManyData()
    {
        StudentDao studentDao = DBController.getDaoSession().getStudentDao();
        StudentCourseDao studentCourseDao = DBController.getDaoSession().getStudentCourseDao();
        CourseDao courseDao = DBController.getDaoSession().getCourseDao();
        
        Student student = new Student();
        student.setName("小明");
        student.setStudentId((long)3001);
        studentDao.insertInTx(student);
        
        Course course = new Course();
        course.setCourseId((long)40001);
        course.setCourseName("语文");
        courseDao.insertInTx(course);
        
        // 小明选了课程--语文
        StudentCourse studentCourse = new StudentCourse();
        studentCourse.setCourse(course);
        studentCourse.setStudent(student);
        studentCourseDao.insertInTx(studentCourse);
        
        Student student2 = new Student();
        student2.setName("老王");
        student2.setStudentId((long)3002);
        studentDao.insertInTx(student2);
        
        Course course2 = new Course();
        course2.setCourseId((long)40002);
        course2.setCourseName("数学");
        courseDao.insertInTx(course2);
        
        Course course3 = new Course();
        course3.setCourseId((long)40003);
        course3.setCourseName("英语");
        courseDao.insertInTx(course3);
        
        // 小明选了课程---数学
        StudentCourse studentCourse2 = new StudentCourse();
        studentCourse2.setCourse(course2);
        studentCourse2.setStudent(student);
        studentCourseDao.insertInTx(studentCourse2);
        
        // 老王选了课程---语文
        StudentCourse studentCourse3 = new StudentCourse();
        studentCourse3.setCourse(course);
        studentCourse3.setStudent(student2);
        studentCourseDao.insertInTx(studentCourse3);
        
        // 老王选了课程---数学
        StudentCourse studentCourse4 = new StudentCourse();
        studentCourse4.setCourse(course2);
        studentCourse4.setStudent(student2);
        studentCourseDao.insertInTx(studentCourse4);
        
        // 老王选了课程---英语
        StudentCourse studentCourse5 = new StudentCourse();
        studentCourse5.setCourse(course3);
        studentCourse5.setStudent(student2);
        studentCourseDao.insertInTx(studentCourse5);
    }
    
    /**
     * 一对多清空数据
     * 
     * @see [类、类#方法、类#成员]
     */
    private void clearOneToManyData()
    {
        DBController.getDaoSession().getCustomerDao().deleteAll();
        DBController.getDaoSession().getOrderInfoDao().deleteAll();
    }
    
    /**
     * 查询数据(一对多)
     * 
     * @see [类、类#方法、类#成员]
     */
    private void selOneToManyData()
    {
        CustomerDao customerDao = DBController.getDaoSession().getCustomerDao();
        Customer customer = customerDao.queryBuilder().where(CustomerDao.Properties.Name.eq("李四")).list().get(0);
        if (null != customer)
        {
            StringBuilder builder = new StringBuilder();
            // 通过customer拿到所有订单信息
            List<OrderInfo> orderInfos = customer.getOrders();
            for (int i = 0; i < orderInfos.size(); i++)
            {
                builder.append("---" + orderInfos.get(i).getMoney() + "\n");
            }
            showDbData(builder.toString());
        }
    }
    
    /**
     * 插入数据(一对多)
     * 
     * @see [类、类#方法、类#成员]
     */
    private void insertOneToManyData()
    {
        CustomerDao customerDao = DBController.getDaoSession().getCustomerDao();
        // 顾客
        Customer customer = new Customer();
        customer.setCustomerId((long)20001);
        customer.setName("李四");
        customerDao.insertInTx(customer);
        
        // 订单
        OrderInfoDao orderDao = DBController.getDaoSession().getOrderInfoDao();
        
        // 订单一
        OrderInfo order = new OrderInfo();
        order.setCustomerId((long)20001);
        order.setMoney(209);
        order.setOrderId((long)112);
        orderDao.insertInTx(order);
        
        // 订单二
        OrderInfo order1 = new OrderInfo();
        order1.setCustomerId((long)20001);
        order1.setMoney(443);
        order1.setOrderId((long)113);
        orderDao.insertInTx(order1);
        
        // 订单三
        OrderInfo order2 = new OrderInfo();
        order2.setCustomerId((long)20001);
        order2.setMoney(777);
        order2.setOrderId((long)114);
        orderDao.insertInTx(order2);
    }
    
    /**
     * 清空数据
     * 
     * @see [类、类#方法、类#成员]
     */
    private void clearData()
    {
        DBController.getDaoSession().getManDao().deleteAll();
        DBController.getDaoSession().getWomanDao().deleteAll();
    }
    
    /**
     * 查询数据
     * 
     * @see [类、类#方法、类#成员]
     */
    private void selData()
    {
        ManDao manDao = DBController.getDaoSession().getManDao();
        Man man = manDao.queryBuilder().where(ManDao.Properties.Name.eq("张三")).list().get(0);
        
        if (null != man)
        {
            showDbData("张三的媳妇是：" + man.getWoman().getName());
        }
    }
    
    /**
     * 插入数据(一对一)
     * 
     * @see [类、类#方法、类#成员]
     */
    private void insertData()
    {
        ManDao manDao = DBController.getDaoSession().getManDao();
        WomanDao womanDao = DBController.getDaoSession().getWomanDao();
        
        // new三个男人
        Man man = new Man();
        Man man2 = new Man();
        Man man3 = new Man();
        // new三个女人
        Woman woman = new Woman();
        Woman woman2 = new Woman();
        Woman woman3 = new Woman();
        
        man.setCardManNum("320321002001004");
        man.setAge(27);
        man.setName("王坤");
        man.setAddress("中国上海");
        
        man2.setCardManNum("320321990880770");
        man2.setAge(54);
        man2.setName("张三");
        man2.setAddress("中国浙江");
        
        man3.setCardManNum("320321776885994");
        man3.setAge(54);
        man3.setName("赵云");
        man3.setAddress("中国山东");
        
        woman.setName("花花");
        woman.setAge(34);
        woman.setCardWomanNum("42042110098765");
        woman.setAddress("乌鲁木齐");
        
        woman2.setName("刘玉芬");
        woman2.setAge(54);
        woman2.setCardWomanNum("42042119887323");
        woman2.setAddress("苏州");
        
        woman3.setName("琉璃灯");
        woman3.setAge(29);
        woman3.setCardWomanNum("42042133321112");
        woman3.setAddress("青岛");
        
        /**
         * 设置一对一的数据
         */
        man.setWoman(woman);
        man2.setWoman(woman2);
        man3.setWoman(woman3);
        
        woman.setMan(man);
        woman2.setMan(man2);
        woman3.setMan(man3);
        
        manDao.insertInTx(man, man2, man3);
        womanDao.insertInTx(woman, woman2, woman3);
    }
    
    /**
     * 显示查询的数据
     * 
     * @see [类、类#方法、类#成员]
     */
    private void showDbData(String text)
    {
        tvShow.setText(text);
    }
    
}
